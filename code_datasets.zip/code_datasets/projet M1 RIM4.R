#//////////*INSTALLED PACKAGES*\\\\\\\\\\

install.packages("processx")
install.packages("readxl")
install.packages("haven")
install.packages("backports")
install.packages("colorspace")
install.packages("httpuv")
install.packages("xesreadR")
install.packages("FactoMineR")
install.packages("stringi")
install.packages("edeaR")
install.packages("processmapR")
install.packages("processmonitR")
install.packages("bupaR")
install.packages("dplyr")
install.packages("devtools")
install.packages("petrinetR")
install.packages("processanimateR")
install.packages("tidyverse")
install.packages("lubridate")
install.packages("quantmod")
install.packages("eventdataR")

#//////////*USED PACKAGES*\\\\\\\\\\
library("dplyr",warn.conflicts = FALSE)
library("xesreadR",warn.conflicts = FALSE)
library("edeaR")
library("bupaR",warn.conflicts = FALSE)
library("processanimateR")
library("tidyverse", warn.conflicts = FALSE) 
library("lubridate")
library("quantmod")
library("eventdataR")
library("stringi")
library("processmapR")
library("processmonitR")
library("devtools")

#//////////*DATA*\\\\\\\\\\
#Extraction

twoPerson_labour <- read_xes("C:/Users/Marwan/Downloads/data/activitylog_uci_detailed_labour.xes")
twoPerson__weekends <- read_xes("C:/Users/Marwan/Downloads/data/activitylog_uci_detailed_weekends.xes")
hh102_labour <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh102_labour.xes")
hh102_weekends <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh102_weekends.xes")
hh104_labour <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh104_labour.xes")
hh104_weekends <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh104_weekends.xes")
hh110_labour <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh110_labour.xes")
hh110_weekends <- read_xes("C:/Users/Marwan/Downloads/data/edited_hh110_weekends.xes")

#Data cleaning : data structure comprehension
class(twoPerson_labour)
dim(twoPerson_labour)
names(twoPerson_labour)
str(twoPerson_labour)
glimpse(twoPerson_labour)
summary(twoPerson_labour)
class(twoPerson__weekends)
dim(twoPerson__weekends)
names(twoPerson__weekends)
str(twoPerson__weekends)
glimpse(twoPerson__weekends)
summary(twoPerson__weekends)
class(hh102_labour)
dim(hh102_labour)
names(hh102_labour)
str(hh102_labour)
glimpse(hh102_labour)
summary(hh102_labour)
class(hh102_weekends)
dim(hh102_weekends)
names(hh102_weekends)
str(hh102_weekends)
glimpse(hh102_weekends)
summary(hh102_weekends)
class(hh104_labour)
dim(hh104_labour)
names(hh104_labour)
str(hh104_labour)
glimpse(hh104_labour)
summary(hh104_labour)
class(hh104_weekends)
dim(hh104_weekends)
names(hh104_weekends)
str(hh104_weekends)
glimpse(hh104_weekends)
summary(hh104_weekends)
class(hh110_labour)
dim(hh110_labour)
names(hh110_labour)
str(hh110_labour)
glimpse(hh110_labour)
summary(hh110_labour)
class(hh110_weekends)
dim(hh110_weekends)
names(hh110_weekends)
str(hh110_weekends)
glimpse(hh110_weekends)
summary(hh110_weekends)

#PREPROCESSING
#Removing Start and End & Removing Column

cleaning_individu <- function(table){
  
  table <- rbind(eval(parse(text = paste(table, "_labour", sep = ""))),eval(parse(text = paste(table, "_weekends", sep = ""))))
  table <- table[table$activity_id != 'Start' & table$activity_id != 'End',] %>% select(c(-CASE_creator,-Column_4)) 
  table <- table[with(table, order(timestamp)),]
  table <- transmute(table,activity_instance_id=rep(1:(nrow(table)/2), times = 1,length.out = nrow(table), each = 2)) %>%
    eventlog(
      case_id = "CASE_concept_name",
      activity_id = "activity_id",
      activity_instance_id = "activity_instance_id",
      lifecycle_id = "lifecycle_id",
      timestamp = "timestamp",
      resource_id = "resource_id")
  return(table)
}

cleaning_individu_104 <- function(table){
  hh104_labour <- select(hh104_labour, -work, -CASE_creator)
  hh104_weekends <- select(hh104_weekends, -Column_4, -CASE_creator)
  table <- rbind(eval(parse(text = paste(table, "_labour", sep = ""))),eval(parse(text = paste(table, "_weekends", sep = ""))))
  table <- table[table$activity_id != 'Start' & table$activity_id != 'End',] 
  table <- table[with(table, order(timestamp)),]
  table <- transmute(table,activity_instance_id=rep(1:(nrow(table)/2), times = 1,length.out = nrow(table), each = 2)) %>%
    eventlog(
      case_id = "CASE_concept_name",
      activity_id = "activity_id",
      activity_instance_id = "activity_instance_id",
      lifecycle_id = "lifecycle_id",
      timestamp = "timestamp",
      resource_id = "resource_id")
  return(table)
}

cleaning<- function(table){
  table <- table[table$activity_id != 'Start' & table$activity_id != 'End',] %>% select(c(-CASE_creator,-Column_4)) 
  table <- transmute(table,activity_instance_id=rep(1:(nrow(table)/2), times = 1,length.out = nrow(table), each = 2)) %>%
    eventlog(
      case_id = "CASE_concept_name",
      activity_id = "activity_id",
      activity_instance_id = "activity_instance_id",
      lifecycle_id = "lifecycle_id",
      timestamp = "timestamp",
      resource_id = "resource_id")
  return(table)
}


cleaning04<- function(table){
  table <- table[table$activity_id != 'Start' & table$activity_id != 'End',] %>% select(c(-CASE_creator,-work)) 
  table <- transmute(table,activity_instance_id=rep(1:(nrow(table)/2), times = 1,length.out = nrow(table), each = 2)) %>%
    eventlog(
      case_id = "CASE_concept_name",
      activity_id = "activity_id",
      activity_instance_id = "activity_instance_id",
      lifecycle_id = "lifecycle_id",
      timestamp = "timestamp",
      resource_id = "resource_id")
  return(table)
}

#Process Discovery
############################==>ANALYSIS OF Individuals VS. Individuals<==############################

hh102 <- cleaning_individu("hh102")
hh104 <- cleaning_individu_104("hh104")
hh110 <- cleaning_individu("hh110")

#Data structure
n_cases(hh102)
cases(hh102)
n_activities(hh102)
n_events(hh102)
activity_labels(hh102)
activities(hh102)
traces(hh102)


n_cases(hh104)
cases(hh104)
n_activities(hh104)
n_events(hh104)
activity_labels(hh104)
activities(hh104)
traces(hh104)

n_cases(hh110)
cases(hh110)
n_activities(hh110)
n_events(hh110)
activity_labels(hh110)
activities(hh110)
traces(hh110)

mapping(hh102)
mapping(hh104)
mapping(hh110)

##Entry & Exit points

hh102 %>% start_activities("activity") %>% plot()
hh102 %>% end_activities("activity") %>% plot()

hh104 %>% start_activities("activity") %>% plot()
hh104 %>% end_activities("activity") %>% plot()

hh110 %>% start_activities("activity") %>% plot()
hh110 %>% end_activities("activity") %>% plot()

#Activity frequency
hh102 %>%  activity_frequency(level = "activity") 
hh104 %>%  activity_frequency(level = "activity") 
hh110 %>%  activity_frequency(level = "activity") 

###Calculate the average trace length
trace_length(hh102)
trace_length(hh104)
trace_length(hh110)

#Data structure
class(hh102)
dim(hh102)
names(hh102)
str(hh102)
glimpse(hh102)
summary(hh102)

class(hh104)
dim(hh104)
names(hh104)
str(hh104)
glimpse(hh104)
summary(hh104)

class(hh110)
dim(hh110)
names(hh110)
str(hh110)
glimpse(hh110)
summary(hh110)

#Cleaning
hh102_labour <- cleaning(hh102_labour)

hh102_weekends <- cleaning(hh102_weekends)

hh104_weekends <- cleaning(hh104_weekends)

hh110_labour <- cleaning(hh110_labour)

hh110_weekends <- cleaning(hh110_weekends)


#Precedence matrix
hh102 %>% precedence_matrix(type="absolute") %>% plot()

hh104 %>% precedence_matrix(type="absolute") %>% plot()

hh110 %>% precedence_matrix(type="absolute") %>% plot()

### Plot of min, max and average number of repetitions
number_of_repetitions(hh102,level = "case") %>% plot()
number_of_repetitions(hh104,level = "case") %>% plot()
number_of_repetitions(hh110,level = "case") %>% plot()

### Plot of number of repetitions per activity
number_of_repetitions(hh102,level = "activity") %>% plot()
number_of_repetitions(hh104,level = "activity") %>% plot()
number_of_repetitions(hh110,level = "activity") %>% plot()

rework_dashboard(hh102)
rework_dashboard(hh104)
rework_dashboard(hh110)

##Process Variants
###Trace Explorer

trace_explorer(hh102)
trace_explorer(hh104)
trace_explorer(hh110)

###Processsing Time or Time per activity
#The processing time can be computed at the levels log, trace, case, activity and resource-activity. It can only be calculated when there are both start and end timestamps available for activity instances.
hh102 %>% 
  processing_time("activity", unit = "hours") %>%
  plot()

hh104 %>% 
  processing_time("activity", unit = "hours") %>%
  plot()

hh110 %>% 
  processing_time("activity", unit = "hours") %>%
  plot()

#The idle time is the time that there is no activity in a case or for a resource. It can only be calculated when there are both start and end timestamps available for activity instances. It can be computed at the levels trace, resource, case and log, and using different time units.
hh102 %>% idle_time(level = "case", units = "hours") %>%
  plot()

hh104 %>% idle_time("case", units = "hours") %>%
  plot()

hh110 %>% idle_time("case", units = "hours") %>%
  plot()

#PERFORMANCE ANALYSIS
##Time Analysis
###Throupought Time or Average duration of recordings

#The throughput time is the time form the very first event to the last event of a case. The levels at which it can be computed are log, trace, or case.
hh102 %>% 
  throughput_time(level="log", units = "hours")
hh104 %>% 
  throughput_time(level="log", units = "hours")
hh110 %>% 
  throughput_time(level="log", units = "hours")

#The resource frequency metric allows the computation of the number/frequency of resources at the levels of log, case, activity, resource, and resource-activity.
hh102 %>% resource_frequency("activity")
hh104 %>% resource_frequency("activity")
hh110 %>% resource_frequency("activity")

#Resource involvement refers to the notion of the number of cases in which a resource is involved. It can be computed at levels case, resource, and resource-activity.
hh102 %>% resource_involvement("resource-activity") %>% plot
hh104 %>% resource_involvement("resource-activity") %>% plot
hh110 %>% resource_involvement("resource-activity") %>% plot

#The resource specalization metric shows whether resources are specialized in certain activities or not. It can be calculated at the levels log, case, resource and activity.
#hh102 %>% resource_specialisation("activity")

#Activity presence shows in what percentage of cases an activity is present. It has no level-argument.
hh102 %>% activity_presence() %>%
  plot()

hh104 %>% activity_presence() %>%
  plot()

hh110 %>% activity_presence() %>%
  plot()

#The trace coverage metric shows the relationship between the number of different activity sequences (i.e. traces) and the number of cases they cover.
hh102 %>% trace_coverage("trace") %>%
  plot()

hh104 %>% trace_coverage("trace") %>%
  plot()

hh110 %>% trace_coverage("trace") %>%
  plot()

##Dotted Chart
###Eating
hh102_eating <- hh102[ which(hh102$activity_id=='mealpreperation' | hh102$activity_id=='eatingdrinking' | hh102$activity_id=='snack' ),]
hh102_eating %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
###Sleeping
hh110_sleep <- hh110[ which(hh110$activity_id=='sleep') , ]
hh104_sleep <- hh104[ which(hh104$activity_id=='sleep') , ]
hh102_sleep <- hh102[ which(hh102$activity_id=='sleep') , ]
hh110_sleep %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
hh104_sleep %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
hh102_sleep %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
###Working
hh110_work <- hh110[ which(hh110$activity_id=='work') , ]
hh102_work <- hh102[ which(hh102$activity_id=='work') , ]
hh104_work <- hh104[ which(hh104$activity_id=='work') , ]
hh102_work %>%
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")

hh102 %>% dotted_chart(x = "absolute", sort = "duration")
hh104 %>% dotted_chart(x = "absolute", sort = "duration")
hh110 %>% dotted_chart(x = "absolute", sort = "duration")


process_matrix(hh102)
process_matrix(hh104)
process_matrix(hh110)

##Process Map
process_map(hh102)
process_map(hh104)
process_map(hh110)

###Processing Time
hh102 %>% 
  process_map(type = performance(FUN = median, units = "hours"))
hh104 %>% 
  process_map(type = performance(FUN = median, units = "hours"))
hh110 %>% 
  process_map(type = performance(FUN = median, units = "hours"))

##FILTER
###Performance
#60 percentence of activities
hh102 %>%
  # Filter for the 60% most common activities
  filter_activity_frequency(percentage = 0.6) %>%
  process_map(
    type_nodes = performance(mean, "hours"),
    type_edges = performance(mean, "hours")
  )
# Select top 20% of cases according to trace frequency , happy
happy_path <- hh102 %>% 
  filter_trace_frequency(percentage = 0.2)

# Draw a process map of absolute case frequency
happy_path %>% 
  process_map(type = frequency(value = "absolute_case"))


###Filter by activity presence
hh104 %>%
  filter_activity_presence(activities = "medication" , method = "none") %>% 
  filter_activity_frequency(percentage = 0.6) %>%
  process_map(
    type_nodes = performance(mean, "hours"),
    type_edges = performance(mean, "hours")
  )

#filter_time_period(hh104, interval = ymd(c("22:00:00","06:00:00")), method = "trim keeps") %>% 
# process_map(
#  type_nodes = performance(mean, "hours"),
#  type_edges = performance(mean, "hours")
#  )

hh000 <- rbind(hh102,hh104)
hh000 <- rbind(hh000,hh110)
hh000 <- hh000[with(hh000, order(timestamp)),]
hh000<-transmute(hh000,activity_instance_id=rep(1:(nrow(hh000)/2), times = 1,length.out = nrow(hh000), each = 2)) 

hh000 %>%
  # Filter for the 60% most common activities
  filter_activity_frequency(percentage = 0.6) %>%
  process_map(
    type_nodes = frequency(value = "relative"),
    type_edges = performance(mean, "hours")
  )




############################==>ANALYSIS OF Working Days VS. Weekends<==############################
#hhwork
hh104_labour<-cleaning04(hh104_labour)

hhwork <- rbind(hh102_labour,hh104_labour,hh110_labour)
hhwork <- hhwork[with(hhwork, order(timestamp)),]
hhwork<-transmute(hhwork,activity_instance_id=rep(1:(nrow(hhwork)/2), times = 1,length.out = nrow(hhwork), each = 2))
#hhweekends

hhweekends <- rbind(hh102_weekends,hh104_weekends,hh110_weekends)
hhweekends <- hhweekends[with(hhweekends, order(timestamp)),]
hhweekends<-transmute(hhweekends,activity_instance_id=rep(1:(nrow(hhweekends)/2), times = 1,length.out = nrow(hhweekends), each = 2))


##STARTS
hhwork %>% start_activities("activity") %>% plot()
hhweekends %>% start_activities("activity") %>% plot()

###Exits 
hhwork %>% end_activities("activity") %>% plot()
hhweekends %>% end_activities("activity") %>% plot()

###Calculate the average trace length
trace_length(hhweekends)
trace_length(hhwork)

###Activity Presence
activity_presence(hhwork) %>% plot()
activity_presence(hhweekends) %>% plot()

#PERFORMANCE ANALYSIS
##Time Analysis
###Throupought Time or Average duration of recordings
hhwork %>% 
  throughput_time(level="log", units = "hours") 
hhweekends %>% 
  throughput_time(level="log", units = "hours")

###Idle Time or Missing activities
hhwork %>% 
  idle_time(level = "log", units = "hours")
hhweekends %>% 
  idle_time(level = "log", units = "hours")
###Processsing Time or Time per activity
hhwork %>% 
  # Calculate variation in processing times of activity durations
  processing_time(level = "activity", units= "hours") %>% 
  # Plot it
  plot()
hhweekends %>% 
  # Calculate variation in processing times of activity durations
  processing_time(level = "activity", units= "hours") %>% 
  # Plot it
  plot()
hh104 %>% 
  # Calculate variation in processing times of activity durations
  processing_time(level = "activity", units= "hours") %>% 
  # Plot it
  plot()

##Process Map
###Processing Time
hh102 %>% 
  process_map(type = performance(FUN = median, units = "hours"))
hh104 %>% 
  process_map(type = performance(FUN = median, units = "hours"))
hh110 %>% 
  process_map(type = performance(FUN = median, units = "hours"))


##Dotted Chart
###Eating
hhwork_eating <- hhwork[ which(hhwork$activity_id=='mealpreperation' | hhwork$activity_id=='eatingdrinking' | hhwork$activity_id=='snack' ),]
hhweekends_eating <- hhweekends[ which(hhweekends$activity_id=='mealpreperation' | hhweekends$activity_id=='eatingdrinking' | hhweekends$activity_id=='snack' ),]
hhweekends_eating %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
hhwork_eating %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
###Sleeping
hhwork_sleep <- hhwork[ which(hhwork$activity_id=='sleep') , ]
hhweekends_sleep <- hhweekends[ which(hhweekends$activity_id=='sleep') , ]

hhwork_sleep %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
hhweekends_sleep %>% 
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")
###Working
hh110_work <- hh110[ which(hh110$activity_id=='work') , ]
hh102_work <- hh102[ which(hh102$activity_id=='work') , ]
hh104_work <- hh104[ which(hh104$activity_id=='work') , ]
hh102_work %>%
  dotted_chart(x = "relative_day", sort = "start_day", units = "secs")

##FILTER
###Performance
#60 percentence of activities
hh102 %>%
  # Filter for the 60% most common activities
  filter_activity_frequency(percentage = 0.6) %>%
  process_map(
    type_nodes = performance(mean, "hours"),
    type_edges = performance(mean, "hours")
  )
# Select top 20% of cases according to trace frequency , happy
happy_path <- hh102 %>% 
  filter_trace_frequency(percentage = 0.2)

# Draw a process map of absolute case frequency
happy_path %>% 
  process_map(type = frequency(value = "absolute_case"))


###Filter by activity presence
hh104 %>%
  filter_activity_presence(activities = "medication" , method = "none") %>% 
  filter_activity_frequency(percentage = 0.6) %>%
  process_map(
    type_nodes = performance(mean, "hours"),
    type_edges = performance(mean, "hours")
  )

n_cases(hh102)
n_cases(hh000)
n_events(hh000)

